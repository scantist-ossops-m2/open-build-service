class Collection < ActiveXML::Node
  default_find_parameter :match
end
