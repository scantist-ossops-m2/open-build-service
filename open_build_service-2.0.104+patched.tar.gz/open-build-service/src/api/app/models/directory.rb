class Directory < ActiveXML::Base
end
