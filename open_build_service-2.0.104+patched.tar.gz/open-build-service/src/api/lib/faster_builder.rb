require "xml/libxml"

module FasterBuilder
end
