VALID_REQUEST_STATES = [:new, :deleted, :declined, :accepted, :review, :revoked, :superseded]
