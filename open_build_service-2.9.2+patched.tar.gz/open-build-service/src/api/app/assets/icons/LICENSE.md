The icons used are a mixture of the [Silk Icons set](http://www.famfamfam.com/lab/icons/silk/)
by Mark James licensed [CC BY 2.5](https://creativecommons.org/licenses/by/2.5/) and
[Tango Icon Library](http://tango.freedesktop.org) from the public domain and images/logos
that are all rights reserved.
