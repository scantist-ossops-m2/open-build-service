class Fileinfo < ActiveXML::Node
end
