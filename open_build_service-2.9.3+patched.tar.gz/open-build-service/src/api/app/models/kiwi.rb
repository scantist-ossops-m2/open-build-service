module Kiwi
  def self.table_name_prefix
    'kiwi_'
  end
end
