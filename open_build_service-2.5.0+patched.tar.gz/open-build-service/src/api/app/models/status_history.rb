class StatusHistory < ActiveRecord::Base
end
