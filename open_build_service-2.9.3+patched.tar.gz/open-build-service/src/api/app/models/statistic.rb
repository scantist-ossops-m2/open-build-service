class Statistic < ActiveXML::Node
end
