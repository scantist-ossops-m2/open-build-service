class AttribAllowedValue < ActiveRecord::Base
  belongs_to :attrib_type
end
