class BlacklistTag < ActiveRecord::Base
end
