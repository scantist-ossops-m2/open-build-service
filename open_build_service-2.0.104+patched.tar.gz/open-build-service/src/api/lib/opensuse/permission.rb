#require "project"
#require "package"

#
# This is basically only a helper class around permission checking for user model
#

module Suse

  class Permission

    def to_s
      return "OpenSUSE Permissions for user #{@user.login}"
    end

    def initialize( u )
      @user = u
      logger.debug "User #{@user.login} initialised"
    end

    def project_change?( project = nil )
      # one is project admin if he has the permission Project_Admin or if he
      # is the owner of the project
      logger.debug "User #{@user.login} wants to change the project"

      return true if @user.has_global_permission?( "global_project_change" )

      if project.kind_of? DbProject
        prj = project
      elsif project.kind_of? Project or project.kind_of? String
        prj = DbProject.find_by_name( project )
      end

      if prj.nil?
        raise ArgumentError, "unable to find project object for #{project}"
      end

      return true if @user.can_modify_project?( prj )
      return false
    end

    # args can either be an instance of the respective class (Package, Project),
    # the database object or package/project names.
    #
    # the second arg can be omitted if the first one is a Package object. second
    # arg is needed if first arg is a string

    def package_change?( package, project=nil )
      logger.debug "User #{@user.login} wants to change the package"

      # Get DbPackage object
      if package.kind_of? DbPackage
        pkg = package
      else
        if project.nil?
          if not package.kind_of? Package
            raise RuntimeError, "autofetch of project only works with objects of class Package"
          end
          if package.parent_project_name.nil?
            raise RuntimeError, "unable to determine parent project for package #{package}"
          end
          project = package.parent_project
        end

        if package.kind_of? Package
           package = package.name
        end
        if project.kind_of? Project
           project = project.name
        end
        if project.kind_of? String
           project = project
        end

        pkg = DbPackage.find_by_project_and_name( project, package )
        if pkg.nil?
          raise ArgumentError, "unable to find package object for #{project} / #{package}"
        end
      end

      return true if @user.can_modify_package?( pkg )
      return false
    end

    def package_create?( obj )
      logger.debug "User #{@user.login} wants to change the package"


      # Get DbPackage object
      if obj.kind_of? DbPackage
        prj = obj.db_project
      elsif obj.kind_of? DbProject
        prj = obj
      elsif obj.kind_of? Package
        prj = DbProject.find_by_name( obj.parent_project.name )
      elsif obj.kind_of? Project
        prj = DbProject.find_by_name( obj.name )
      elsif obj.kind_of? String
        prj = DbProject.find_by_name( obj )
      else
        raise RuntimeError, "Unhandle object type"
      end

      if pkg.nil?
        raise "unable to find package object for #{project} / #{package}"
      end

      return true if @user.can_create_package_in?( prj )
      return false
    end

    def method_missing( perm, *args, &block)

      logger.debug "Dynamic Permission requested: <#{perm}>"

      if @user
        if @user.has_global_permission? perm.to_s
          logger.debug "User #{@user.login} has permission #{perm}"
          return true
        else
          logger.debug "User #{@user.login} does NOT have permission #{perm}"
          return false
        end
      else
        logger.debug "Permission check failed because no user is checked in"
        return false
      end
    end

    def logger
      RAILS_DEFAULT_LOGGER
    end
  end
end
