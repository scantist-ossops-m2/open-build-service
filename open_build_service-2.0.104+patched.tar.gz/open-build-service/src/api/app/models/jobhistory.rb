class Jobhistory < ActiveXML::Base
end
