#
# setup ActiveRBAC's configuration below
#