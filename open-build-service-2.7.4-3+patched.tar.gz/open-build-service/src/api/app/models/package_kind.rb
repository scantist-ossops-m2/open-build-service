
class PackageKind < ActiveRecord::Base
  belongs_to :package
end
