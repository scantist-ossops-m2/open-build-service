module RpmHelper
end
