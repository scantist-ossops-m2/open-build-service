module PlatformHelper
end
