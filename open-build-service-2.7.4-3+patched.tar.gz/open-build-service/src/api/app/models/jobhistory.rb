class Jobhistory < ActiveXML::Node
end
