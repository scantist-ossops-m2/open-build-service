class Collection < ActiveXML::Base
  default_find_parameter :match
end
