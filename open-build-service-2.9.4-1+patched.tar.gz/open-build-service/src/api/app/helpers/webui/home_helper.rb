module Webui::HomeHelper
  include Webui::RequestHelper
end
