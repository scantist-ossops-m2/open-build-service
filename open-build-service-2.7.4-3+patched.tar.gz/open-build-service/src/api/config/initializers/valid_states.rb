VALID_REQUEST_STATES = [:new, :deleted, :declined, :accepted, :review, :revoked, :superseded]
VALID_REVIEW_STATES = [:new, :declined, :accepted, :superseded, :obsoleted]
