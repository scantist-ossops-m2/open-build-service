class MainController < ApplicationController
  layout "rbac"
end
