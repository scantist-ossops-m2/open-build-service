class BuilddepInfo < ActiveXML::Node
end
