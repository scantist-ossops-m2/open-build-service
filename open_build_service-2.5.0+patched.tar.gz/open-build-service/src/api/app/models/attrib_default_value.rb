class AttribDefaultValue < ActiveRecord::Base
  belongs_to :attrib_type
end
